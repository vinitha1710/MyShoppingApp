import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const AccountScreen = () => {
  return (
    <View>
      <Text>coming soon</Text>
    </View>
  )
}

export default AccountScreen

const styles = StyleSheet.create({})