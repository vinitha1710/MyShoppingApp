import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ReorderScreen = () => {
  return (
    <View>
      <Text>Coming soon</Text>
    </View>
  )
}

export default ReorderScreen

const styles = StyleSheet.create({})