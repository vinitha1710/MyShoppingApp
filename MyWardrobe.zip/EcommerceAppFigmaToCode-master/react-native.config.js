module.exports = {
  projects: {
    android: {},
    ios: {},
  },
  assets: ['./assets/fonts'],
};
